# mypackage

This is an example of how to create a package

#Follow the following steps